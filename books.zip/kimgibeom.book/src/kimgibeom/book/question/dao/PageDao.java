package kimgibeom.book.question.dao;

public interface PageDao {
	int getTotRowCnt();
}
