package kimgibeom.book.question.dao.map;

public interface PageMap {
	int getTotRowCnt();
}
