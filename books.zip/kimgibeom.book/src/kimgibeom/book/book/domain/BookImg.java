package kimgibeom.book.book.domain;

public class BookImg {
	private String bookImgName;

	public BookImg() {
	}

	public BookImg(String bookImgName) {
		this.bookImgName = bookImgName;
	}

	public String getBookImgName() {
		return bookImgName;
	}

	public void setBookImgName(String bookImgName) {
		this.bookImgName = bookImgName;
	}
}